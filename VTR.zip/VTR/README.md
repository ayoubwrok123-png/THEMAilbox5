# Vitara Mail

A simple Gmail IMAP client built with React + Express.

## 🚀 How to Run

### 1. Clone repo
```bash
git clone https://github.com/YOURNAME/vitara-mail.git
cd vitara-mail
