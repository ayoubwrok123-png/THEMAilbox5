import React, { useState, useCallback } from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import LoginScreen from './components/LoginScreen';
import MailboxScreen from './components/MailboxScreen';
import TabBar from './components/TabBar';
import './index.css';

const App = () => {
  const [mailboxes, setMailboxes] = useState([]);
  const [activeTab, setActiveTab] = useState(0);
  const [showLogin, setShowLogin] = useState(false);

  const handleLogin = useCallback((credentials) => {
    if (mailboxes.length >= 5) {
      return false;
    }

    const newMailbox = {
      id: Date.now(),
      email: credentials.email,
      password: credentials.password,
      isActive: true
    };

    setMailboxes(prev => [...prev, newMailbox]);
    setActiveTab(mailboxes.length);
    setShowLogin(false);
    return true;
  }, [mailboxes.length]);

  const handleCloseMailbox = useCallback((index) => {
    setMailboxes(prev => prev.filter((_, i) => i !== index));
    if (activeTab >= index && activeTab > 0) {
      setActiveTab(prev => prev - 1);
    }
  }, [activeTab]);

  const handleNewMailbox = useCallback(() => {
    if (mailboxes.length < 5) {
      setShowLogin(true);
    }
  }, [mailboxes.length]);

  if (mailboxes.length === 0 && !showLogin) {
    return (
      <Router>
        <div className="min-h-screen bg-gray-50">
          <LoginScreen onLogin={handleLogin} />
        </div>
      </Router>
    );
  }

  if (showLogin) {
    return (
      <Router>
        <div className="min-h-screen bg-gray-50">
          <LoginScreen 
            onLogin={handleLogin} 
            onCancel={() => setShowLogin(false)}
            isAdditional={true}
          />
        </div>
      </Router>
    );
  }

  return (
    <Router>
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <TabBar 
          mailboxes={mailboxes}
          activeTab={activeTab}
          onTabChange={setActiveTab}
          onCloseMailbox={handleCloseMailbox}
          onNewMailbox={handleNewMailbox}
        />
        
        {mailboxes[activeTab] && (
          <MailboxScreen 
            key={mailboxes[activeTab].id}
            mailbox={mailboxes[activeTab]}
          />
        )}
      </div>
    </Router>
  );
};

export default App;
