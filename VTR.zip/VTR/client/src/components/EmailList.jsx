import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { formatDistanceToNow } from '../utils/emailUtils';

const EmailList = ({ emails, loading, selectedEmail, onSelectEmail }) => {
  const [visibleCount, setVisibleCount] = useState(5);
  const [scrollContainer, setScrollContainer] = useState(null);

  useEffect(() => {
    if (!scrollContainer) return;

    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = scrollContainer;
      if (scrollTop + clientHeight >= scrollHeight - 100 && visibleCount < emails.length) {
        setVisibleCount((prev) => Math.min(prev + 5, emails.length));
      }
    };

    scrollContainer.addEventListener('scroll', handleScroll);
    return () => scrollContainer.removeEventListener('scroll', handleScroll);
  }, [scrollContainer, visibleCount, emails.length]);

  const visibleEmails = emails.slice(0, visibleCount);

  if (loading && emails.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-gray-500">Loading emails...</p>
        </div>
      </div>
    );
  }

  if (emails.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-500 text-lg">No emails</p>
          <p className="text-gray-400 text-sm mt-1">This folder is empty</p>
        </div>
      </div>
    );
  }

  return (
    <div ref={setScrollContainer} className="flex-1 overflow-y-auto">
      <AnimatePresence>
        {visibleEmails.map((email, index) => (
          <motion.div
            key={email.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ delay: index * 0.05 }}
            onClick={() => onSelectEmail(email)}
            className={`p-4 border-b border-gray-100 cursor-pointer transition-colors hover:bg-gray-50 ${
              selectedEmail?.id === email.id ? 'bg-blue-50 border-blue-200' : ''
            } ${email.isNew ? 'bg-yellow-50 border-yellow-200' : ''}`}
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1 min-w-0">
                <p
                  className={`text-sm font-medium truncate ${
                    email.isRead ? 'text-gray-600' : 'text-gray-900'
                  }`}
                >
                  {email.from}
                </p>
                <p
                  className={`text-xs mt-1 ${
                    email.isRead ? 'text-gray-400' : 'text-gray-500'
                  }`}
                >
                  {formatDistanceToNow(email.received)}
                </p>
              </div>
              {email.isNew && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="w-2 h-2 bg-blue-600 rounded-full ml-2 flex-shrink-0"
                />
              )}
            </div>
            <h3
              className={`text-sm mb-1 line-clamp-1 ${
                email.isRead ? 'text-gray-700 font-normal' : 'text-gray-900 font-medium'
              }`}
            >
              {email.subject}
            </h3>
            <p className="text-xs text-gray-500 line-clamp-2">{email.preview}</p>
          </motion.div>
        ))}
      </AnimatePresence>

      {visibleCount < emails.length && (
        <div className="p-4 text-center">
          <div className="w-6 h-6 border-2 border-gray-300 border-t-blue-600 rounded-full animate-spin mx-auto" />
          <p className="text-xs text-gray-400 mt-2">Loading more emails...</p>
        </div>
      )}
    </div>
  );
};

export default EmailList;
