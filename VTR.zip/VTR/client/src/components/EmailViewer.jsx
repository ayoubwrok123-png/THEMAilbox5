import React from 'react';
import { motion } from 'framer-motion';
import { Mail, Calendar, User } from 'lucide-react';
import { formatDate } from '../utils/emailUtils';

const EmailViewer = ({ email, mailbox }) => {
  if (!email) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Mail className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-500 mb-2">No email selected</h3>
          <p className="text-gray-400">Choose an email from the list to view its contents</p>
        </div>
      </div>
    );
  }

  const renderEmailBody = () => {
    if (email.htmlBody) {
      return (
        <div
          className="prose max-w-none"
          dangerouslySetInnerHTML={{ __html: email.htmlBody }}
        />
      );
    }

    return (
      <div className="whitespace-pre-wrap text-gray-700 leading-relaxed">
        {email.textBody || email.preview}
      </div>
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="flex-1 flex flex-col bg-white"
    >
      <div className="border-b border-gray-200 p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h1 className="text-xl font-heading font-semibold text-gray-900 mb-2">
              {email.subject}
            </h1>
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4" />
                <span>{email.from}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span>{formatDate(email.received)}</span>
              </div>
            </div>
          </div>
          <div className="text-xs text-gray-400">To: {mailbox}</div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl">{renderEmailBody()}</div>
      </div>
    </motion.div>
  );
};

export default EmailViewer;
