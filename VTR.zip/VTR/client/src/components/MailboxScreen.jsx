import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { RefreshCw, Inbox, AlertTriangle } from 'lucide-react';
import EmailList from './EmailList';
import EmailViewer from './EmailViewer';
import { useEmailSync } from '../hooks/useEmailSync';

const MailboxScreen = ({ mailbox }) => {
  const [selectedFolder, setSelectedFolder] = useState('inbox');
  const [selectedEmail, setSelectedEmail] = useState(null);
  const [lastRefresh, setLastRefresh] = useState(null);

  const { emails, loading, lastSync, error, refresh } = useEmailSync(
    mailbox.email,
    selectedFolder,
    mailbox.password
  );

  useEffect(() => {
    setSelectedEmail(null);
  }, [selectedFolder]);

  const handleRefresh = async () => {
    setLastRefresh(new Date());
    await refresh();
  };

  const handleSelectEmail = (email) => {
    setSelectedEmail(email);
    if (!email.isRead) {
      email.isRead = true;
    }
  };

  const folders = [
    { id: 'inbox', name: 'Inbox', icon: Inbox, count: selectedFolder === 'inbox' ? emails.length : 0 },
    { id: 'spam', name: 'Spam', icon: AlertTriangle, count: selectedFolder === 'spam' ? emails.length : 0 }
  ];

  return (
    <div className="flex-1 flex bg-white">
      {/* Sidebar */}
      <div className="w-64 bg-gray-50 border-r border-gray-200 flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-heading font-semibold text-gray-900 truncate">
              {mailbox.email}
            </h2>
            <motion.button
              whileHover={{ rotate: 180 }}
              whileTap={{ scale: 0.9 }}
              onClick={handleRefresh}
              disabled={loading}
              className="p-2 rounded-lg hover:bg-gray-200 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 text-gray-600 ${loading ? 'animate-spin' : ''}`} />
            </motion.button>
          </div>

          {lastSync && (
            <p className="text-xs text-gray-500">
              Last sync: {lastSync.toLocaleTimeString()}
            </p>
          )}
        </div>

        <div className="flex-1 p-2">
          {folders.map((folder) => {
            const Icon = folder.icon;
            return (
              <motion.button
                key={folder.id}
                whileHover={{ x: 4 }}
                onClick={() => setSelectedFolder(folder.id)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors mb-1 ${
                  selectedFolder === folder.id
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{folder.name}</span>
                {folder.count > 0 && (
                  <span
                    className={`ml-auto text-xs px-2 py-1 rounded-full ${
                      selectedFolder === folder.id
                        ? 'bg-blue-200 text-blue-800'
                        : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {folder.count}
                  </span>
                )}
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Email List */}
      <div className="w-80 border-r border-gray-200 flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <h3 className="font-heading font-semibold text-gray-900 capitalize">
            {selectedFolder}
          </h3>
          <p className="text-sm text-gray-500 mt-1">
            {emails.length} emails
          </p>
        </div>

        <EmailList
          emails={emails}
          loading={loading}
          selectedEmail={selectedEmail}
          onSelectEmail={handleSelectEmail}
        />
      </div>

      {/* Email Viewer */}
      <EmailViewer email={selectedEmail} mailbox={mailbox.email} />
    </div>
  );
};

export default MailboxScreen;
