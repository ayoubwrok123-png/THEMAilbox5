import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Mail } from 'lucide-react';

const TabBar = ({ mailboxes, activeTab, onTabChange, onCloseMailbox, onNewMailbox }) => {
  const getEmailUsername = (email) => {
    return email.split('@')[0];
  };

  return (
    <div className="bg-white border-b border-gray-200 px-4 py-2">
      <div className="flex items-center gap-2 max-w-7xl mx-auto">
        <AnimatePresence>
          {mailboxes.map((mailbox, index) => (
            <motion.div
              key={mailbox.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className={`relative flex items-center gap-2 px-4 py-2 rounded-lg cursor-pointer transition-colors ${
                activeTab === index
                  ? 'bg-blue-100 text-blue-700 border border-blue-200'
                  : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
              }`}
              onClick={() => onTabChange(index)}
            >
              <Mail className="w-4 h-4" />
              <span className="text-sm font-medium max-w-32 truncate">
                {getEmailUsername(mailbox.email)}
              </span>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={(e) => {
                  e.stopPropagation();
                  onCloseMailbox(index);
                }}
                className="ml-1 p-1 rounded-full hover:bg-red-100 hover:text-red-600 transition-colors"
              >
                <X className="w-3 h-3" />
              </motion.button>
            </motion.div>
          ))}
        </AnimatePresence>

        {mailboxes.length < 5 && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onNewMailbox}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
          >
            <Plus className="w-4 h-4" />
            New Mailbox
          </motion.button>
        )}

        <div className="ml-auto text-xs text-gray-500">
          {mailboxes.length}/5 mailboxes
        </div>
      </div>
    </div>
  );
};

export default TabBar;
