import { useState, useEffect, useCallback } from 'react';

export const useEmailSync = (email, folder, password) => {
  const [emails, setEmails] = useState([]);
  const [loading, setLoading] = useState(false);
  const [lastSync, setLastSync] = useState(null);
  const [error, setError] = useState(null);

  // Fetch emails from backend API
  const fetchEmails = useCallback(async () => {
    if (!email || !password) return;

    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/emails", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, folder }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to fetch emails: ${response.statusText}`);
      }

      const data = await response.json();
      setEmails(data.slice(0, 20)); // keep max 20 emails
      setLastSync(new Date());
    } catch (err) {
      console.error("Error fetching emails:", err);
      setError(err.message || "Could not load emails");
    } finally {
      setLoading(false);
    }
  }, [email, folder, password]);

  // Refresh for new emails
  const refresh = useCallback(async () => {
    if (!email || !password) return;

    try {
      const response = await fetch("/api/emails", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, folder }),
      });

      if (response.ok) {
        const newData = await response.json();

        const existingIds = new Set(emails.map((e) => e.id));
        const newEmails = newData.filter((email) => !existingIds.has(email.id));

        if (newEmails.length > 0) {
          const markedNew = newEmails.map((email) => ({ ...email, isNew: true }));
          setEmails((prev) => [...markedNew, ...prev].slice(0, 20));
        }
      }
      setLastSync(new Date());
    } catch (err) {
      console.error("Error refreshing emails:", err);
    }
  }, [email, folder, password, emails]);

  // Auto-refresh every 10s
  useEffect(() => {
    if (!email || !password) return;
    const interval = setInterval(refresh, 10000);
    return () => clearInterval(interval);
  }, [email, password, refresh]);

  // Initial fetch
  useEffect(() => {
    fetchEmails();
  }, [fetchEmails]);

  return {
    emails,
    loading,
    lastSync,
    error,
    refresh,
  };
};
