import express from "express";
import cors from "cors";
import { ImapFlow } from "imapflow";
import { simpleParser } from "mailparser";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// === EMAIL API ===
app.post("/api/emails", async (req, res) => {
  const { email, password, folder } = req.body;

  if (!email || !password || !folder) {
    return res.status(400).json({ error: "Missing credentials or folder" });
  }

  const client = new ImapFlow({
    host: "imap.gmail.com",
    port: 993,
    secure: true,
    auth: { user: email, pass: password },
  });

  try {
    await client.connect();
    await client.mailboxOpen(folder === "spam" ? "[Gmail]/Spam" : "INBOX");

    // Get today's date in IMAP format (DD-MMM-YYYY)
    const today = new Date();
    const day = today.getDate().toString().padStart(2, '0');
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const month = months[today.getMonth()];
    const year = today.getFullYear();
    const todayStr = `${day}-${month}-${year}`;

    // Search for emails from today
    const searchResults = await client.search({
      since: todayStr
    });

    console.log(`Found ${searchResults.length} emails from today`);

    // Get the last 20 emails (most recent first)
    const recentUids = searchResults.slice(-20).reverse();
    
    const messages = [];
    if (recentUids.length > 0) {
      for await (let msg of client.fetch(recentUids, { source: true, flags: true })) {
        const parsed = await simpleParser(msg.source);
        messages.push({
          id: msg.uid,
          from: parsed.from?.text || "Unknown",
          subject: parsed.subject || "(no subject)",
          received: parsed.date || new Date(),
          preview: parsed.text?.slice(0, 120) || "",
          textBody: parsed.text,
          htmlBody: parsed.html,
          isRead: msg.flags.has("\\Seen"),
        });
      }
    }

    await client.logout();
    
    // Sort by received date (most recent first)
    messages.sort((a, b) => new Date(b.received) - new Date(a.received));
    
    console.log(`Returning ${messages.length} emails from today`);
    res.json(messages);
  } catch (err) {
    console.error("IMAP error:", err);
    res.status(500).json({ error: err.message });
  }
});

// === SERVE FRONTEND ===
app.use(express.static(path.join(__dirname, "public")));
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, '0.0.0.0', () => console.log(`✅ Vitara Mail running at http://0.0.0.0:${PORT}`));
